public class HashClass {
    public int hashad;
    public int hashkey;
    public String word;

    HashClass(int hashad, int hashkey, String word) {
        this.hashad = hashad;
        this.hashkey = hashkey;
        this.word = word;
    }

}
